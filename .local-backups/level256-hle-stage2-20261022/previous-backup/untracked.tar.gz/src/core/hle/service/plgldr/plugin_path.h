// Copyright 2026 Azahar Emulator Project
// Licensed under GPLv2 or any later version

#pragma once

#include <string>
#include "common/common_types.h"

namespace Service::PLGLDR {

enum class PluginPathSource {
    Level256,
    TitleSpecific,
    Default,
    None,
};

PluginPathSource ChoosePluginPathSource(u64 title_id, bool level256_file_exists,
                                        bool select_pressed, bool title_plugin_exists,
                                        bool default_plugin_exists);
bool IsLevel256SupportedTitle(u64 title_id);
std::string MakeGuestPluginPath(std::string plugin_path, const std::string& sdmc_root);

} // namespace Service::PLGLDR
