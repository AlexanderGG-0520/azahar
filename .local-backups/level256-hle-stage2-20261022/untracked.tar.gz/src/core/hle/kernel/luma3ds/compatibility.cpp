// Copyright 2026 Azahar Emulator Project
// Licensed under GPLv2 or any later version

#include "core/hle/kernel/luma3ds/compatibility.h"

namespace Kernel::Luma3DS {
// Keep the compatibility boundary in a compiled translation unit so HLE dispatch code can depend
// on one kernel-owned interface instead of Level256 policy headers.
}
