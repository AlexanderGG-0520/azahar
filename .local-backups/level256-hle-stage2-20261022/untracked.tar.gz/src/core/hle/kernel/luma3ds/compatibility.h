// Copyright 2026 Azahar Emulator Project
// Licensed under GPLv2 or any later version

#pragma once

#include "common/common_types.h"

namespace Kernel::Luma3DS {

/// Runtime authority for Luma kernel-extension behavior. The loader supplies only facts it has
/// verified from the active plugin mapping; this context intentionally has no title-ID policy.
struct CompatibilityContext {
    bool enabled{};
    bool plugin_loaded{};
    bool plugin_integrity_verified{};
    u32 owner_process_id{};
    u32 plugin_code_begin{};
    u32 plugin_code_end{};
    u32 bootloader_code_begin{};
    u32 bootloader_code_end{};

    constexpr bool IsVerifiedPluginCall(u32 process_id, u32 pc) const {
        const bool in_plugin = plugin_code_begin < plugin_code_end && pc >= plugin_code_begin &&
                               pc < plugin_code_end;
        const bool in_bootloader = bootloader_code_begin < bootloader_code_end &&
                                   pc >= bootloader_code_begin && pc < bootloader_code_end;
        return enabled && plugin_loaded && plugin_integrity_verified && owner_process_id != 0 &&
               process_id == owner_process_id && (in_plugin || in_bootloader);
    }
};

struct SystemInfoResponse {
    u32 result;
    u64 value;
};

/// Whether an extension SVC may be dispatched for this caller. SVC semantics are title agnostic;
/// authority comes from the verified plugin mapping and the compatibility-mode setting.
constexpr bool CanDispatchExtension(const CompatibilityContext& context, u32 process_id,
                                    u32 pc) {
    return context.IsVerifiedPluginCall(process_id, pc);
}

constexpr bool IsExtensionSVC(u32 svc_id) {
    return svc_id == 0x80 || (svc_id >= 0x90 && svc_id <= 0x94) ||
           (svc_id >= 0xA0 && svc_id <= 0xA3);
}

/// Luma models the data cache as coherent with the emulated memory system. These operations are
/// therefore successful no-ops; instruction-cache operations still invalidate Dynarmic blocks.
constexpr bool IsDataCacheOperation(u32 svc_id) {
    return svc_id == 0x91 || svc_id == 0x92;
}

constexpr bool IsInstructionCacheOperation(u32 svc_id) {
    return svc_id == 0x93 || svc_id == 0x94;
}

/// Validate the CustomBackdoor ABI's guest callback address before a plugin-specific adapter
/// chooses a supported operation. This does not permit arbitrary guest code execution by HLE.
constexpr bool IsValidCustomBackdoorCallback(const CompatibilityContext& context, u32 process_id,
                                             u32 callback) {
    return (callback & 3) == 0 && context.enabled && context.plugin_loaded &&
           context.plugin_integrity_verified && process_id == context.owner_process_id &&
           context.owner_process_id != 0 && context.plugin_code_begin < context.plugin_code_end &&
           callback >= context.plugin_code_begin && callback < context.plugin_code_end;
}

/// Luma's GetSystemInfo hook reports its kernel extension marker without changing emulator IDs.
constexpr bool TryGetLumaSystemInfoResponse(bool enabled, u32 type, s32 param,
                                            SystemInfoResponse& response) {
    if (!enabled || type != 0x20000 || param != 0) {
        return false;
    }
    response = {.result = 1, .value = 0};
    return true;
}

} // namespace Kernel::Luma3DS
